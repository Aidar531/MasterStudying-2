public class RMSValues {
    private String ID;

    private double phA = 0;
    private double phB = 0;
    private double phC = 0;

    private double angleA = 0;
    private double angleB = 0;
    private double angleC = 0;

    private double time = 0;

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public double getAngleA() {
        return angleA;
    }

    public void setAngleA(double angleA) {
        this.angleA = angleA;
    }

    public double getAngleB() {
        return angleB;
    }

    public void setAngleB(double angleB) {
        this.angleB = angleB;
    }

    public double getAngleC() {
        return angleC;
    }

    public void setAngleC(double angleC) {
        this.angleC = angleC;
    }

    public double getTime() {
        return time;
    }

    public void setTime(double time) {
        this.time = time;
    }

    public double getPhA() {
        return phA;
    }

    public void setPhA(double phA) {
        this.phA = phA;
    }

    public double getPhB() {
        return phB;
    }

    public void setPhB(double phB) {
        this.phB = phB;
    }

    public double getPhC() {
        return phC;
    }

    public void setPhC(double phC) {
        this.phC = phC;
    }
}
