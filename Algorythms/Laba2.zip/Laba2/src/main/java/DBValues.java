public class DBValues {
    private double diffValueA;
    private double brakingValueA;

    private double diffValueB;
    private double brakingValueB;


    private double diffValueC;
    private double brakingValueC;

    public double getDiffValueA() {
        return diffValueA;
    }

    public void setDiffValueA(double diffValueA) {
        this.diffValueA = diffValueA;
    }

    public double getBrakingValueA() {
        return brakingValueA;
    }

    public void setBrakingValueA(double brakingValueA) {
        this.brakingValueA = brakingValueA;
    }

    public double getDiffValueB() {
        return diffValueB;
    }

    public void setDiffValueB(double diffValueB) {
        this.diffValueB = diffValueB;
    }

    public double getBrakingValueB() {
        return brakingValueB;
    }

    public void setBrakingValueB(double brakingValueB) {
        this.brakingValueB = brakingValueB;
    }

    public double getDiffValueC() {
        return diffValueC;
    }

    public void setDiffValueC(double diffValueC) {
        this.diffValueC = diffValueC;
    }

    public double getBrakingValueC() {
        return brakingValueC;
    }

    public void setBrakingValueC(double brakingValueC) {
        this.brakingValueC = brakingValueC;
    }


}
