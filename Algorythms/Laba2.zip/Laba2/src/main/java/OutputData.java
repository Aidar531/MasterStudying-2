public class OutputData {

    public void trip(boolean trip) {
        Charts.addDiscreteData(0,trip);
    }
}
