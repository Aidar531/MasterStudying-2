import org.apache.jena.datatypes.xsd.XSDDatatype;
import org.apache.jena.ontology.*;
import org.apache.jena.rdf.model.*;
import org.apache.jena.util.FileManager;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;
import ru.smarteps.scl.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.*;
import java.util.*;


public class TEST {

    private static TSubstation mySubstation;
    private static TVoltage voltage;
    private static List<TPowerTransformerEnum> ptrTypes;



    public static void main(String[] args) throws OWLOntologyCreationException, FileNotFoundException, OWLOntologyStorageException {

        // создание пустой модели
        OWLOntologyManager manager = OWLManager.createOWLOntologyManager();

        File file = new File("src/resources/ontology.owl");;
        OWLOntology ontology = manager.loadOntologyFromOntologyDocument(file);
        System.out.println("Load ontology: " + ontology);

//        home/aidar/Рабочий стол/MasterStudying#2/Ontology/swrlEgine/
        File scdFile = new File("/src/resources/twoVL_SSD_LIV2.ssd");

        SCL tsub = null;
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(SCL.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            tsub = (SCL) jaxbUnmarshaller.unmarshal(scdFile);
        } catch (JAXBException e) {
            e.printStackTrace();
        }

//        String ns = ontology.getOntologyID().getOntologyIRI().get().toString() + "#";
//
//
//        OWLDataFactory df = manager.getOWLDataFactory(); // Позволяет работат непосредственно с данными антологии
//
//        OWLClass FirstClass = df.getOWLClass(IRI.create(ns + "FirstClass"));//Создаем класс
//        OWLClass SecondClass = df.getOWLClass(IRI.create(ns + "SecondClass"));//Создаем класс
//        OWLObjectProperty prop = df.getOWLObjectProperty(IRI.create(ns + "AnotherProperty"));
//        OWLDataProperty dp = df.getOWLDataProperty(IRI.create(ns + "dataProperty"));
//        OWLIndividual ind1 = df.getOWLNamedIndividual(IRI.create(ns + "ind1"));
//        OWLIndividual ind2 = df.getOWLNamedIndividual(IRI.create(ns + "ind2"));
//
//
//        OWLReasonerFactory rf = new StructuralReasonerFactory();
//        OWLReasoner reasoner = rf.createReasoner(ontology);//Создаем ризонер для нашей онтологии
//
//        OWLAxiom ax1 = df.getOWLClassAssertionAxiom(FirstClass,ind1);
//        OWLAxiom ax2 = df.getOWLClassAssertionAxiom(SecondClass,ind2);
//        AddAxiom ad1 = new AddAxiom(ontology,ax1);
//        AddAxiom ad2 = new AddAxiom(ontology,ax2);
//        manager.applyChange(ad1);
//        manager.applyChange(ad2);
//
//        ax1 = df.getOWLDataPropertyAssertionAxiom(dp,ind1,2);
//        ad1 = new AddAxiom(ontology,ax1);
//        manager.applyChange(ad1);
//
//        OWLAxiom ax = df.getOWLObjectPropertyAssertionAxiom(prop,ind1,ind2);
//        AddAxiom ad = new AddAxiom(ontology,ax);
//        manager.applyChange(ad);
//
//        OutputStream out = new FileOutputStream("src/resources/ontology_new.owl");
//
//        manager.saveOntology(ontology, out);

        List<TSubstation> substations = tsub.getSubstation();
        mySubstation = substations.get(0);
        for (TVoltageLevel voltageLevel : mySubstation.getVoltageLevel()) {
            voltage = voltageLevel.getVoltage();

            for (TBay bay : voltageLevel.getBay()) {
                TText text = bay.getText();
                for (TConnectivityNode connectivityNode: bay.getConnectivityNode()) {
                    connectivityNode.getName();
                }
            }
        }

    }
}

