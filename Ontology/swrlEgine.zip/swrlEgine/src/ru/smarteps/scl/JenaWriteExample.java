package ru.smarteps.scl;//package ru.smarteps.scl;
//
//import org.apache.jena.ontology.OntModel;
//import org.apache.jena.ontology.OntModelSpec;
//import org.apache.jena.rdf.model.Model;
//import org.apache.jena.rdf.model.ModelFactory;
//import org.apache.jena.rdf.model.Resource;
//
//
//import javax.smartcardio.TerminalFactory;
//
//public class JenaWriteExample {
//    private static TTerminal terminal = new TTerminal();
//
//    public JenaWriteExample() {
//        terminal.setName("Terminal1");
//        terminal.setConnectivityNode("substation1/voltageLevel1/bay3/connvtyNode1");
//        terminal.setSubstationName("substation1");
//        terminal.setVoltageLevelName("voltageLevel1");
//        terminal.setBayName("bay3");
//        terminal.setCNodeName("connvtyNode1");
//    }
//
//    OntModel ontModel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
//
//
//
//
//
//}
